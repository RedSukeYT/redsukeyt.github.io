
console.log("RedSuke Studio loaded successfully");
